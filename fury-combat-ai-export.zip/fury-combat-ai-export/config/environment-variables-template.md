# Environment Variables Template

## Required Variables

### PORT
- **What it does:** Sets the port number for the web server (both Vite dev server and production static server)
- **Set by:** Replit (automatically assigned)
- **Example value:** `3000`
- **Used in:** `vite.config.ts`, `api-server/src/index.ts`

## Optional Variables

### BASE_PATH
- **What it does:** Sets the URL base path prefix for the frontend app
- **Default:** `/`
- **Used in:** `vite.config.ts` as Vite's `base` option
- **Notes:** Only change if the app is served under a subpath (e.g., `/fury-combat/`)

### SESSION_SECRET
- **What it does:** Secret key for session signing in the API server
- **Required for:** API server sessions (not currently used by the frontend)
- **Format:** Random string, minimum 32 characters recommended
- **Do not commit this value to source control**

### DATABASE_URL
- **What it does:** PostgreSQL connection string for the database
- **Required for:** Database operations via Drizzle ORM (not currently used by the frontend)
- **Format:** `postgresql://user:password@host:port/database`
- **Do not commit this value to source control**

## Notes

- The marketing website (fury-combat) only requires `PORT` to function
- `SESSION_SECRET` and `DATABASE_URL` are for the API server infrastructure, which is present but minimally used
- In Replit, `PORT` is set automatically; in other environments, set it manually
