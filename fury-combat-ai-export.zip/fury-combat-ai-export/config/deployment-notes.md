# Deployment Notes

## How Deployment Works

The Fury Combat website is deployed as a static single-page application (SPA) through Replit's publishing system.

### Build Process
1. Replit runs `pnpm --filter @workspace/fury-combat run build`
2. Vite compiles the React/TypeScript code into optimized static files
3. Output goes to `artifacts/fury-combat/dist/`
4. The built files include HTML, CSS, JavaScript bundles, and image assets

### Serving in Production
1. The static files are served by `npx serve dist/ -l $PORT`
2. A SPA rewrite rule (`/* → /index.html`) ensures all routes are handled by the React app
3. This means `/private-instruction`, `/executive-readiness`, etc. all serve `index.html` and let the client-side router handle the route

### Critical Deployment Details

1. **SPA rewrite is mandatory.** Without it, direct URL access to any service page returns a 404. The rewrite rule is configured in `artifact.toml`.

2. **No server-side rendering.** The app is fully client-rendered. The initial HTML is a blank shell until JavaScript loads. SEO is partially addressed by JSON-LD structured data embedded directly in `index.html`.

3. **Images are bundled.** All 39 photos are processed by Vite's asset pipeline and included in the build output with hashed filenames. No external image hosting is needed.

4. **Google Fonts require internet.** Typography depends on Google Fonts CDN. If fonts fail to load, the browser falls back to generic serif and sans-serif fonts.

5. **No environment variables needed at runtime.** The built static files contain no runtime environment variable references. `PORT` is only needed by the `serve` command.

## Domain Considerations

- The site is currently served at a `.replit.app` subdomain
- Custom domain support is available through Replit's deployment settings
- If a custom domain is configured, update the canonical URL in structured data and social meta tags

## Post-Deployment Checklist

1. Verify all 8 service pages load via direct URL access
2. Verify the home page sections scroll correctly
3. Verify phone and email CTAs work on mobile
4. Verify the gallery lightbox opens
5. Test the mobile hamburger menu and Services dropdown
6. Check Google Search Console for structured data validation
