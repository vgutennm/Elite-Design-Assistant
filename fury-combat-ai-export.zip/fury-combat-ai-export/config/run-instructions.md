# Run Instructions

## Running in Replit

The project is configured with Replit workflows. To start the development server:

1. Open the Replit project
2. The workflow `artifacts/fury-combat: web` should start automatically
3. If not, start it manually from the Workflows panel
4. The app will be accessible in the Preview pane at the root path `/`

The workflow runs: `pnpm --filter @workspace/fury-combat run dev`

## Running Locally (Outside Replit)

### Prerequisites
- Node.js 18 or higher
- pnpm 8 or higher

### Steps
1. Clone the repository
2. Install dependencies:
   ```bash
   pnpm install
   ```
3. Set the PORT environment variable:
   ```bash
   export PORT=3000
   ```
4. Start the development server:
   ```bash
   pnpm --filter @workspace/fury-combat run dev
   ```
5. Open `http://localhost:3000` in your browser

### Building for Production
```bash
pnpm --filter @workspace/fury-combat run build
```
The output will be in `artifacts/fury-combat/dist/`.

### Serving the Production Build Locally
```bash
cd artifacts/fury-combat
npx serve dist/ -l 3000
```

## Project Structure

This is a pnpm monorepo. Key directories:
- `artifacts/fury-combat/` - The marketing website (React + Vite)
- `artifacts/api-server/` - Express API server (minimal)
- `lib/` - Shared libraries (database, API client, schemas)

## Notes

- The photo assets must be in `attached_assets/` with the naming convention `furycombat-website-photos-XXX_TIMESTAMP.ext`
- The development server uses Vite with hot module replacement
- The `allowedHosts: true` setting in `vite.config.ts` is necessary for Replit's proxy; in other environments this can be tightened
