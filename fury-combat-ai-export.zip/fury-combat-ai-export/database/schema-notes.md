# Database Schema Notes

## Current State

The Fury Combat marketing website does not use a database. All content is hardcoded in TypeScript source files.

## Database Infrastructure (Present but Unused)

The monorepo includes database infrastructure in `lib/db/`:

### Drizzle ORM Configuration
- **ORM:** Drizzle ORM for PostgreSQL
- **Config file:** `lib/db/drizzle.config.ts`
- **Connection:** Uses `DATABASE_URL` environment variable
- **Schema location:** `lib/db/src/schema/index.ts`

### Current Schema
The schema file (`lib/db/src/schema/index.ts`) is empty (no tables defined).

### Migration Support
Drizzle Kit is configured for migration generation, but no migrations exist because there are no tables.

## In-Code Data Structures

### Service Data (the primary "data model")
Location: `artifacts/fury-combat/src/data/services.ts`

```typescript
interface ServiceData {
  title: string
  route: string
  price: string
  metaTitle: string
  metaDescription: string
  subheadline: string
  overview: string
  whoFor: string[]
  whatYouGet: string[]
  trainingFocus: string[]
  likelyOutcomes: string[]
  whyChoose: string
  faqs: { q: string; a: string }[]
  relatedSlugs: string[]
  heroImage?: string
}
```

8 service records exist with this shape.

### Relationships
- Services reference each other via `relatedSlugs` (string array of route slugs)
- Service cards on the home page map to service detail pages via the `serviceRoutes` lookup

## If a Database Were Added

For future extensions (booking, client portal, CMS), suggested tables:

1. **inquiries** - Capture contact form submissions (name, email, phone, service_interest, message, created_at)
2. **bookings** - Schedule training sessions (client_id, service_slug, date, time, status, notes)
3. **clients** - Client profiles (name, email, phone, notes, created_at)
4. **services** - Move service data from TypeScript to database for CMS editing
5. **gallery_images** - Manage gallery photos with ordering and captions
6. **site_settings** - Key-value store for configurable site content
