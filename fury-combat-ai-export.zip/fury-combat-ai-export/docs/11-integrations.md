# 11 - Integrations

## Overview

This application has minimal external integrations, consistent with its role as a static marketing site.

## Active Integrations

### Google Fonts
- **What:** Cinzel (serif headings) and Inter (body text) loaded from Google Fonts CDN
- **Where:** `index.html` `<link>` tags with preconnect
- **Purpose:** Typography that reinforces the premium brand identity

### Google Maps
- **What:** Google Maps search URL for directions
- **Where:** "Get Directions" buttons throughout the site
- **Purpose:** Allow visitors to navigate to the Brooklyn training location
- **URL pattern:** `https://www.google.com/maps/search/?api=1&query=Fury+Combat+Systems+24+Cobeck+Ct+Brooklyn+NY+11223`

### Google Business / Reviews
- **What:** Direct link to Google's review submission page
- **Where:** Footer and contact section
- **Purpose:** Encourage clients to leave Google reviews
- **URL:** `https://search.google.com/local/writereview?placeid=ChIJK3bJOxJGwokRWkZSVj7DV5s`

### Social Media (Outbound Links)
- Facebook: `https://www.facebook.com/furycombatbrooklyn/`
- Instagram: `https://www.instagram.com/david.furie/`
- LinkedIn: `https://www.linkedin.com/in/david-furie-17091548/`
- YouTube: `https://www.youtube.com/channel/UC1bJFJVjk-0AqvfVAj18IOg`
- Instagram Reel: `https://www.instagram.com/reel/DTV6Ia5kesh/`

## Not Integrated (But Available in Monorepo)

### API Server (Express)
- Exists in `artifacts/api-server` with health check endpoint
- Not used by the marketing site
- Could be extended for form submissions, booking, or CRM integration

### Database (PostgreSQL + Drizzle)
- Infrastructure exists in `lib/db`
- No tables defined
- Could be used for lead capture, booking records, or content management

### Replit Integrations
- No Replit integrations are currently configured
- Available options could include email sending, CRM connections, or payment processing

## AI Analysis Note

The integration pattern here is minimal by design. For future apps:
- Google Fonts + Maps + Reviews is a strong baseline for any local service business
- The monorepo already has API server and database infrastructure ready to activate
- Social media links in structured data (`sameAs`) are good SEO practice
