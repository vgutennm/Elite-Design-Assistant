# 15 - Known Issues and Tech Debt

## Known Issues

### Contact Form Does Not Submit
- **Severity:** Medium
- **Description:** The contact form on the home page is presentational only. It renders fields and a submit button but does not send data anywhere.
- **Impact:** Visitors who fill out the form and click submit may be confused when nothing happens.
- **Recommended fix:** Connect the form to an email API (SendGrid, Resend) via the API server, or add a note that the form is for planning purposes only.

### No Analytics
- **Severity:** Low
- **Description:** No page view tracking, no CTA click tracking, no conversion analytics are installed.
- **Impact:** Unable to measure which service pages are most popular or which CTAs drive the most inquiries.
- **Recommended fix:** Add Google Analytics 4, Plausible, or a lightweight tracking solution.

### No Image Optimization
- **Severity:** Low
- **Description:** PNG images (023-039) are 1.5-1.8MB each. Total asset weight is significant.
- **Impact:** Slow initial load on mobile or slower connections.
- **Recommended fix:** Convert PNGs to WebP, add responsive image sizes, implement lazy loading.

### Missing Photo 040
- **Severity:** Cosmetic
- **Description:** There is no photo 040 in the asset set. Photo 036 is used as a substitute where 040 was expected.
- **Impact:** None visible to users; only affects code clarity.

## Tech Debt

### 55 Unused UI Components
- The project includes the full shadcn/ui component library (55 components), but only ~6 are actively used (Button, Input, Textarea, Select, Accordion, Tooltip).
- These add to bundle size and code surface area.
- Consider tree-shaking or removing unused components.

### API Server Is Minimal
- The API server artifact exists with only a health check endpoint.
- It runs in development but serves no purpose for the marketing site.
- Should be either extended (for form submissions, booking) or removed.

### Database Infrastructure Unused
- `lib/db` with Drizzle ORM and PostgreSQL is configured but has no tables.
- Should be either activated or removed to reduce confusion.

### Monorepo Overhead
- The pnpm workspace structure is heavier than needed for a single static marketing site.
- This is acceptable if future features (booking, client portal, CMS) are planned.

### No Error Boundaries
- No React error boundaries protect against component crashes.
- A single component error could white-screen the entire site.

### No Loading States
- Images appear abruptly when loaded; no skeleton screens or blur-up transitions.
- The hero background can flash from blank to visible.

### SiteHeader Scroll State
- The sticky header uses a scroll event listener without throttling.
- Not a performance issue at current scale but could be optimized.

## Workarounds and Shortcuts

1. **Image filename matching:** The `asset()` function uses startsWith prefix matching to handle timestamp suffixes in uploaded filenames. This works but is fragile if file naming conventions change.
2. **Hash navigation from service pages:** Uses `window.location.href` assignment instead of programmatic router navigation because wouter doesn't natively handle cross-page hash navigation.
3. **Service page 404 handling:** The `/:slug` route matches any path, so the ServiceDetail component must internally check if the slug is valid. A more explicit routing approach would be cleaner.
