# 07 - Validation and Error Handling

## Overview

As a static marketing site with no backend form processing, validation and error handling are minimal. This document captures what exists and what is notably absent.

## Form Validation

The home page contact form includes fields for name, email, phone, service interest (dropdown), and message. However:
- The form does not submit to any backend endpoint
- There is no client-side validation logic
- There is no success/error state handling
- The form is presentational only

## Route Handling

- **Valid routes:** Home (`/`) and 8 service slugs are handled by the wouter router
- **Invalid routes:** The `/:slug` catch-all route renders the `ServiceDetail` component, which checks if the slug matches a known service. If not, it displays a "Service Not Found" message with a "Return Home" button
- **Unknown routes:** Any path not matching `/:slug` falls through to the `NotFound` component
- **SPA routing:** The `artifact.toml` includes a rewrite rule (`/* → /index.html`) so direct URL access and page refreshes work in production

## Image Loading

- The `asset()` function uses `import.meta.glob` to match image filenames by prefix
- If an image is not found, the `Img` component renders a gradient placeholder div instead of a broken image
- Gallery images are filtered to remove any undefined entries

## Error Boundaries

- No React error boundaries are implemented
- No global error handling beyond Vite's runtime error overlay (development only)

## Edge Cases Handled

- **Lightbox bounds:** Arrow navigation prevents going below 0 or above the last image index
- **Scroll to top:** Service detail pages scroll to top on mount/slug change
- **Dynamic meta tags:** Service pages update `document.title` and meta description on mount and clean up FAQ schema on unmount

## Notable Gaps

1. Contact form does not submit data
2. No form validation feedback
3. No error boundaries for component crashes
4. No 404 page styling matches the premium brand (it uses a basic centered layout)
5. No loading states for images (they just appear when loaded)

## AI Analysis Note

For a marketing site, the validation needs are minimal. The key reusable pattern is the SPA routing with fallback handling: catch-all route + data lookup + graceful "not found" display. If this were extended to accept form submissions, client-side validation with Zod (already in the monorepo) and a backend API handler would be the natural additions.
