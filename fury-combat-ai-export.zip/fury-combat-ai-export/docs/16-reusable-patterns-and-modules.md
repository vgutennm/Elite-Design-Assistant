# 16 - Reusable Patterns and Modules

## Pattern 1: Service Detail Page Template

### What It Does
A structured marketing page template for any service-based business. Each service page follows a rigid section order: Hero → Overview → Who It's For → What You Get → Training Focus → Likely Outcomes → Why Choose This → FAQ → Related Services → CTA.

### Why It Is Reusable
The `ServiceData` TypeScript interface defines the complete data shape. Any business with multiple service offerings can populate this interface and get fully rendered detail pages.

### Where It Appears
- `src/data/services.ts` - data definitions
- `src/pages/ServiceDetail.tsx` - rendering template

### Future Use
Any service business: law firms (practice areas), consulting firms (service lines), medical practices (specialties), agencies (service packages).

## Pattern 2: Sticky Navigation with Services Dropdown

### What It Does
A responsive sticky header with scroll-triggered background, desktop dropdown menu for services, and full-screen mobile overlay with expandable submenu.

### Why It Is Reusable
Works for any multi-page site with a category of sub-pages. The dropdown/submenu pattern is common for services, products, or portfolio sections.

### Where It Appears
- `src/components/SiteHeader.tsx`

### Future Use
Any multi-page marketing site, SaaS product pages, portfolio sites.

## Pattern 3: Dark Premium Aesthetic System

### What It Does
A complete design token system for premium/luxury brand positioning: near-black backgrounds, deep red primary, Cinzel serif headings, Inter body, sharp-cornered buttons, uppercase tracking-widest labels, grayscale-to-color image transitions.

### Why It Is Reusable
The entire aesthetic is defined in CSS custom properties in `index.css`. Swapping the primary hue and fonts creates a different premium brand without changing component code.

### Where It Appears
- `src/index.css` - theme variables
- All components use the theme tokens

### Future Use
Any luxury, elite, or premium-positioned brand: high-end real estate, private security, executive services, luxury retail.

## Pattern 4: Photo Gallery with Lightbox

### What It Does
A responsive image grid with some images spanning multiple columns/rows, click-to-open full-screen lightbox with keyboard navigation, grayscale hover effects.

### Why It Is Reusable
The pattern works for any visual portfolio: photography, real estate listings, product showcases, event galleries.

### Where It Appears
- Gallery section in `src/pages/Home.tsx`

### Future Use
Portfolio sites, real estate, e-commerce product galleries, event photography.

## Pattern 5: Multi-CTA Conversion Pattern

### What It Does
Every page surface includes multiple conversion actions: phone call, email, directions, Google review. These repeat consistently in service cards, detail page heroes, detail page footers, and the site footer.

### Why It Is Reusable
Any local service business needs multiple contact channels. The pattern of repeating CTAs across every page surface maximizes conversion opportunities.

### Where It Appears
- Service cards, ServiceDetail hero/footer, SiteFooter, Contact section

### Future Use
Any service business, restaurant, medical practice, professional service firm.

## Pattern 6: SEO-First Structured Data

### What It Does
JSON-LD structured data in the HTML head for LocalBusiness and FAQ schemas, plus dynamic FAQ schema injection on route-specific pages.

### Why It Is Reusable
The pattern of static schema in HTML + dynamic schema via JavaScript covers both server-rendered and SPA architectures.

### Where It Appears
- `index.html` - static schemas
- `src/pages/ServiceDetail.tsx` - dynamic FAQ schema

### Future Use
Any local business website, any content site with FAQs.

## Pattern 7: Vite Asset Glob Import

### What It Does
Uses `import.meta.glob` to dynamically import all matching image files, then a helper function resolves filenames by prefix. This handles timestamp-suffixed filenames from upload systems.

### Why It Is Reusable
Any Replit project with uploaded images faces the timestamp-suffix issue. This pattern solves it cleanly.

### Where It Appears
- `src/pages/Home.tsx` - `asset()` function
- `src/pages/ServiceDetail.tsx` - same pattern

### Future Use
Any Replit-hosted project with image assets.

## Pattern 8: Centralized Service Data Architecture

### What It Does
All service information (titles, prices, descriptions, FAQs, metadata) lives in a single TypeScript file with strong typing. Both the home page cards and the detail pages consume the same data source.

### Why It Is Reusable
Eliminates data duplication between overview and detail views. Adding a new service requires only adding one data object.

### Where It Appears
- `src/data/services.ts`
- Consumed by `Home.tsx` and `ServiceDetail.tsx`

### Future Use
Any product catalog, service listing, course catalog, or feature comparison site.
