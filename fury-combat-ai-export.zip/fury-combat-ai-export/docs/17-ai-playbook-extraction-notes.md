# 17 - AI Playbook Extraction Notes

This document is specifically written for an AI agent to extract reusable app-building intelligence from the Fury Combat Systems project.

## What This App Reveals About the Owner's Preferred Way of Building Apps

### Design Philosophy
1. **Premium over generic.** The owner values elevated, authoritative, premium visual design. No templates, no stock-photo filler, no cheesy copy. Dark themes, serif headings, intentional whitespace.
2. **Content integrity.** No fake testimonials, no fabricated statistics, no inflated numbers. Only verifiable credentials and real information.
3. **Founder-led branding.** The business is inseparable from the founder. Every piece of copy reinforces direct access to the expert, not a team or organization.
4. **Function over flash.** Animations are subtle (fade-in, stagger). No parallax, no particle effects, no auto-playing video backgrounds. Visual polish without performance cost.
5. **Mobile-first but desktop-polished.** Responsive design is a requirement, not an afterthought. Mobile navigation gets dedicated attention (full-screen overlay, expandable submenus).

### Content Standards
1. No emoji anywhere in the application
2. Copy must be calm, authoritative, direct, and premium-toned
3. Headings use strong active language without hyperbole
4. Descriptions are concise; no walls of text
5. Pricing is transparent and visible

### Technical Preferences
1. **React + Vite + TypeScript** as the frontend stack
2. **Tailwind CSS** with custom properties for theming
3. **shadcn/ui** component library (selectively used)
4. **wouter** for lightweight client-side routing (not React Router)
5. **Framer Motion** for animations
6. **Cinzel + Inter** font pairing for premium feel
7. **pnpm monorepo** structure for project organization
8. Prefer single-file sections over heavily fragmented component trees

## Recurring Standards That Should Become Default Requirements

### For Any Marketing/Service Website
1. Sticky navigation with scroll-triggered background
2. Mobile hamburger menu with full-screen overlay
3. Services/Products dropdown in desktop nav
4. Phone + Email + Directions as primary CTAs
5. Service detail pages with consistent section structure
6. FAQ sections with JSON-LD schema markup
7. LocalBusiness structured data
8. SPA with rewrite rules for direct URL access
9. Footer with navigation, services links, and contact columns
10. Grayscale-to-color image hover transitions

### For Any App
1. TypeScript with strict typing for data models
2. Centralized data files for repeated content
3. Shared layout components (Header, Footer)
4. Environment variable validation at startup
5. Base path configuration for deployment flexibility
6. Responsive design as a default, never bolted on

## What Should Become Optional Modules in Future App Specs

1. **Contact form with backend** - Not implemented here but commonly needed
2. **Analytics integration** - Should be a checkbox option in future specs
3. **CMS/Admin panel** - For non-technical content management
4. **Booking/scheduling** - For service businesses
5. **Payment processing** - For paid services
6. **Client portal/login** - For repeat clients
7. **Email notifications** - For form submissions and bookings
8. **Image optimization pipeline** - WebP conversion, responsive sizes

## Mistakes or Omissions That Should Become Prevention Rules

### Must-Have Checklist for Future Builds
1. **Never ship a non-functional form.** If a form exists, it must submit data somewhere or be clearly labeled as coming soon.
2. **Always include analytics.** Even a lightweight solution like Plausible.
3. **Always optimize images before launch.** PNGs over 500KB should be converted to WebP.
4. **Always add error boundaries.** A single component crash should not white-screen the entire site.
5. **Always add loading states.** Images should have skeleton/placeholder states.
6. **Always validate the 404 experience.** The not-found page should match the site's brand, not be a generic placeholder.
7. **Remove unused dependencies before production.** 55 UI components installed with only 6 used is unnecessary bundle weight.

### Architecture Prevention Rules
1. If a catch-all route is used (e.g., `/:slug`), the component must handle invalid slugs gracefully.
2. If hash navigation is needed across pages, document the implementation pattern clearly.
3. If an API server exists, it should serve a purpose or be removed.
4. If a database is configured, it should have tables or be removed.

## Questions That Should Always Be Asked Before Building a Similar App

### Business Questions
1. What are all the services/products and their prices?
2. What are the primary conversion actions? (Phone, email, form, booking, purchase?)
3. Is the brand premium, mid-market, or accessible?
4. Is this founder-led or organizational?
5. What credentials or trust signals should be prominently displayed?
6. What photos/assets are available?
7. Is there existing social media to link to?
8. What is the physical address (for local SEO)?
9. Are there any compliance requirements (ADA, GDPR)?
10. Will the site need a CMS for non-technical updates?

### Technical Questions
1. Is this a static marketing site or does it need a backend?
2. Does it need authentication?
3. Does it need form submissions with email notifications?
4. Does it need booking/scheduling?
5. Does it need payment processing?
6. What analytics solution is preferred?
7. Is there a custom domain?
8. What is the expected traffic volume?

## Pieces Worth Turning Into Standard Reusable Templates

### Template 1: Premium Service Business Website
- Dark premium aesthetic (easily re-skinnable via CSS variables)
- Home page with Hero, Credentials, Services, About, Gallery, Contact, FAQ
- Service detail page template with standardized sections
- Sticky nav with dropdown, mobile overlay
- Multi-CTA conversion pattern
- SEO structured data

### Template 2: Service Data Architecture
- TypeScript interface for service data
- Centralized data file consumed by both list and detail views
- FAQ data structure with schema markup generation
- Related items cross-linking

### Template 3: Photo Gallery with Lightbox
- Responsive grid with spanning images
- Click-to-open lightbox with keyboard navigation
- Grayscale hover effects
- Vite glob import for dynamic image loading

### Template 4: Responsive Navigation System
- Desktop: sticky, scroll-aware, with dropdown menu
- Mobile: hamburger trigger, full-screen overlay, expandable submenus
- Hash navigation support for single-page sections
- Cross-page navigation back to home sections

## Recommended Reading Order for Playbook Extraction

An AI agent should read these files in this order:
1. `docs/17-ai-playbook-extraction-notes.md` (this file) - Highest-level intelligence
2. `docs/16-reusable-patterns-and-modules.md` - Concrete reusable patterns
3. `docs/06-business-rules.md` - Brand and content standards
4. `docs/04-ui-pages-and-components.md` - Complete UI inventory
5. `docs/01-app-overview.md` - Business context
6. `app-source/fury-combat-src/data/services.ts` - Data architecture example
7. `app-source/fury-combat-src/pages/ServiceDetail.tsx` - Template pattern example
8. `app-source/fury-combat-src/components/SiteHeader.tsx` - Navigation pattern example
9. `app-source/fury-combat-src/index.css` - Design system
10. `docs/15-known-issues-and-tech-debt.md` - Prevention rules
