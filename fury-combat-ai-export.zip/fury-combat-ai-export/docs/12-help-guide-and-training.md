# 12 - Help Guide and Training

## Overview

This application has no help guide, training section, onboarding flow, or documentation for end users. The FAQ sections serve as the closest equivalent.

## FAQ as Self-Service Help

### Home Page FAQ (8 questions)
Covers foundational questions:
- What is Fury Combat Systems?
- Who is David Furie?
- What kind of training is offered?
- Group vs. private format
- Location
- How to contact
- Who is instruction for?
- Is it only for sport fighting?

### Service Page FAQs (5 questions each, 40 total across 8 pages)
Each service detail page has 5 context-specific FAQs addressing:
- Experience requirements
- Customization options
- Format/privacy
- Differences from other services
- Suitability for specific audiences

## How Users Learn About Services

The site structure guides discovery:
1. **Home page service cards** provide a brief overview of each service with pricing
2. **Learn More buttons** lead to full detail pages
3. **Service detail pages** walk through: Overview → Who It's For → What You Get → Training Focus → Outcomes → Why Choose This → FAQ
4. **Related Services** links at the bottom of each page encourage cross-browsing

## AI Analysis Note

The FAQ-as-help-system pattern is effective for a service-based marketing site. For future apps with more complexity, consider:
- Searchable help/knowledge base
- Contextual help tooltips
- Video walkthroughs
- First-time user onboarding flow

The current pattern of service-specific FAQs with schema markup serves both user education and SEO simultaneously.
