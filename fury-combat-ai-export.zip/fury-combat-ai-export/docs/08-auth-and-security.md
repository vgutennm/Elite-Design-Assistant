# 08 - Auth and Security

## Authentication

This application has no authentication system. It is a fully public marketing website with no login, no user accounts, and no protected routes.

## Session Handling

There are no sessions. The only state is client-side React state (menu open/close, lightbox index).

## Environment Variables and Secrets

### Used in Development/Build
- `PORT` - The port number for the Vite dev server (set automatically by Replit)
- `BASE_PATH` - The base URL path for the app (set to `/`)
- `SESSION_SECRET` - Present in environment but not used by the frontend; belongs to the API server
- `DATABASE_URL` - Present for the API server's database connection; not used by the frontend

### Security Considerations
- No API keys are embedded in the frontend code
- No sensitive data is exposed in the client bundle
- Contact information (phone, email, address) is intentionally public business information
- Social media links are public profile URLs

## Content Security

- Google Fonts loaded from `fonts.googleapis.com` / `fonts.gstatic.com`
- External links use `target="_blank" rel="noreferrer"` to prevent referrer leaking
- No inline scripts beyond the structured data JSON-LD in `index.html`
- Vite development server allows all hosts (`allowedHosts: true`) for Replit proxy compatibility

## Production Deployment Security

- Deployed as a static site via Replit's static hosting
- SPA rewrite rule (`/* → /index.html`) prevents 404s on direct URL access
- No server-side code runs in the frontend deployment
- The API server runs separately with CORS enabled and pino HTTP logging

## AI Analysis Note

For a static marketing site, this security posture is appropriate. Key patterns to carry forward:
- Separate frontend (static) and API server deployments
- No secrets in frontend code
- External link security attributes
- Environment variable validation at startup (both Vite config and API server throw on missing required vars)
