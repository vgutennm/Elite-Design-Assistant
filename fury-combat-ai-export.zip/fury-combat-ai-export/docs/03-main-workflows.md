# 03 - Main Workflows

## Overview

As a static marketing site, the workflows are visitor-facing browsing and conversion flows rather than application workflows.

## Workflow 1: First-Time Visitor Discovery

1. Visitor lands on the home page (likely via Google search or direct URL)
2. Hero section immediately communicates the brand: "Fury Combat Systems" with "Elite Private Training in Brooklyn"
3. Authority strip shows credentials: 10th Dan, Former Special Forces, World Champion, Brooklyn
4. Visitor scrolls through the intro text establishing the premium positioning
5. Private Instruction section presents 8 service cards with pricing
6. Each card has three CTAs: Learn More, Inquire by Phone, Inquire by Email
7. Visitor clicks "Learn More" to visit a detailed service page, or clicks a phone/email CTA to convert immediately

## Workflow 2: Service Page Deep Dive

1. Visitor arrives at a service detail page (via Learn More button, Services dropdown, or direct URL)
2. Hero section shows the service name, price badge, subheadline, and primary CTAs
3. Breadcrumb "All Services" link allows navigation back
4. Visitor scrolls through: Overview, Who This Is For, What You Get, Training Focus, Likely Outcomes, Why Choose This
5. FAQ section answers common questions
6. Related Services section links to 2-3 other services
7. Final CTA section repeats phone and email inquiry buttons
8. Contact strip at bottom shows phone, email, and location

## Workflow 3: Navigation and Exploration

1. Desktop: Sticky header with Home, The System, The Legend, Gallery, Services (dropdown), Contact, FAQ, Inquire Now
2. Services dropdown shows all 8 services with their prices
3. Mobile: Hamburger menu opens full-screen overlay with same navigation
4. Mobile Services section expands/collapses to show all 8 service links
5. Footer provides alternative navigation with Services column, section links, and contact info

## Workflow 4: Gallery Browsing

1. Visitor scrolls to Gallery section on home page
2. 19 images displayed in a responsive grid (some spanning 2 columns/rows)
3. Clicking any image opens a full-screen lightbox
4. Lightbox supports keyboard navigation (arrow keys, Escape)
5. Click-to-close on backdrop

## Workflow 5: Contact / Conversion

1. Phone CTA: `tel:9173402911` opens native dialer
2. Email CTA: `mailto:david.furie@gmail.com` opens email client
3. Directions CTA: Opens Google Maps search for the Brooklyn location
4. Google Review CTA: Opens Google's review page for the business
5. Contact form is presentational (no backend handler)

## AI Analysis Note

The key pattern here is a marketing site with multiple conversion paths (phone, email, directions) repeated consistently across every page. The service detail pages follow a rigid template that could be reused for any service-based business. The "Learn More → Detail Page → CTA" funnel is the primary conversion workflow.
