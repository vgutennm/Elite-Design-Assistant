# 14 - Deployment and Environments

## Local / Development

### How the App Runs
This is a pnpm monorepo with three artifacts:
1. **fury-combat** (marketing website) - React + Vite SPA
2. **api-server** - Express API server (minimal, health check only)
3. **mockup-sandbox** - Vite preview server for design prototyping

### Starting Development
```bash
pnpm --filter @workspace/fury-combat run dev
```
This starts a Vite dev server on the dynamically assigned `PORT` environment variable.

### Key Dev Settings
- Vite base path is configured via `BASE_PATH` environment variable (default: `/`)
- `server.allowedHosts: true` is required because Replit proxies requests through an iframe
- Hot module replacement (HMR) is active in development

## Replit Environment

### Workflows
Three workflows are configured in the Replit environment:
1. `artifacts/fury-combat: web` - runs `pnpm --filter @workspace/fury-combat run dev`
2. `artifacts/api-server: API Server` - runs `pnpm --filter @workspace/api-server run dev`
3. `artifacts/mockup-sandbox: Component Preview Server` - runs `pnpm --filter @workspace/mockup-sandbox run dev`

### Preview
- The app is accessible in Replit's preview pane via path-based routing
- The fury-combat artifact is served at the root path `/`

## Production Deployment

### How It Is Deployed
- Deployed via Replit's built-in publishing system
- The frontend is built as a static SPA with `vite build`
- Output goes to `artifacts/fury-combat/dist/`

### artifact.toml Configuration
```toml
[deploy]
build = "pnpm --filter @workspace/fury-combat run build"
run = "npx serve dist/ -l $PORT"

[[deploy.rewrites]]
source = "/*"
destination = "/index.html"
```

### SPA Rewrite
The `/* → /index.html` rewrite rule is critical: it ensures that direct URL access to service pages (e.g., `/private-instruction`) works correctly instead of returning a 404 from the static file server.

## Environment Variables Required

| Variable | Purpose | Required |
|----------|---------|----------|
| `PORT` | Server port (set automatically by Replit) | Yes |
| `BASE_PATH` | URL base path for the app (default: `/`) | No |
| `SESSION_SECRET` | For API server sessions (not used by frontend) | No |
| `DATABASE_URL` | PostgreSQL connection string (not used by frontend) | No |

## Known Deployment Gotchas

1. **SPA rewrite is essential.** Without the `/* → /index.html` rewrite, service detail pages will 404 on direct access or page refresh.
2. **Vite allowedHosts.** Must be set to `true` for Replit's proxy to work.
3. **Image paths.** All images are bundled by Vite via `import.meta.glob`, so they work in both dev and production without path issues.
4. **Google Fonts.** Loaded via CDN from `index.html`, not bundled. Requires internet access.
5. **No SSR.** The app is fully client-rendered. Initial load shows a blank page until JavaScript loads. This has minor SEO implications, partially mitigated by JSON-LD structured data in the HTML head.
