# 04 - UI Pages and Components

## Pages

### Home Page (`/`)
The home page is a single-page experience with these sections in order:
1. **Hero** - Full-viewport background image, brand name with text-stroke effect, tagline, secondary copy, 3 CTAs (Phone, Email, Directions)
2. **Authority Strip** - 4-column credential display: 10th Dan, Operative, Champion, Brooklyn
3. **Intro** - Centered serif paragraph establishing the brand
4. **Private Instruction** - Section heading, 8 service cards in 3-column grid, 3 training photos
5. **The System** - Two-column layout: text + bullet points on left, 3 images on right
6. **The Legend: David Furie** - 12-column grid: sticky photos on left, scrolling bio on right
7. **Gallery** - 19-image grid with lightbox overlay
8. **Contact** - Two-column: contact info + inquiry form
9. **FAQ** - Accordion with 8 questions
10. **Footer** - 4-column: brand + socials, nav links, services links, contact info

### Service Detail Pages (8 pages, same template)
Routes: `/private-instruction`, `/advanced-tactical-instruction`, `/womens-private-safety-training`, `/tactical-conditioning`, `/young-adult-readiness-training`, `/executive-readiness`, `/family-protection-session`, `/private-workshops`

Each page follows a rigid template:
1. **Hero** - Background image, breadcrumb back link, price badge, H1, subheadline, 3 CTAs
2. **Overview** - Single paragraph in premium language
3. **Who This Is For** - 2-column grid of check-marked items
4. **What You Get** - Numbered list with card-style items
5. **Training Focus** - 3-column grid of chevron-marked items
6. **Likely Outcomes** - Left-bordered accent cards
7. **Why Choose This** - Bordered quote-style card
8. **FAQ** - Accordion with 5 service-specific questions
9. **Related Services** - 3-column grid of linked service cards
10. **Ready to Begin CTA** - Centered heading with phone/email buttons
11. **Contact Strip** - Phone, email, location inline

### Not Found Page (`/404`)
Simple centered message with a link back to home.

## Shared Components

### SiteHeader (`components/SiteHeader.tsx`)
- Fixed/sticky header with scroll-triggered background blur
- Logo links to home
- Desktop: horizontal nav with Services dropdown (animated, click-triggered, shows prices)
- Mobile: hamburger toggle opens full-screen overlay with expandable Services submenu
- "Inquire Now" CTA button on right
- Hash-link navigation with smooth scroll on home page, full page navigation from service pages

### SiteFooter (`components/SiteFooter.tsx`)
- 4-column grid: Brand + socials, Navigation links, Services links, Contact info
- Social icons: Facebook, Instagram, LinkedIn, YouTube
- Google Review and Directions CTAs
- Copyright line

## Design System

### Typography
- **Headings:** Cinzel serif, bold/black, uppercase, tight tracking
- **Body:** Inter sans-serif, light weight, relaxed leading
- **Labels:** Uppercase, tracking-widest, small size
- **Prices:** Mono font, primary color

### Colors
- **Background:** Near-black (#080808, HSL 0 0% 3%)
- **Primary:** Deep red (HSL 350 89% 45%)
- **Text:** White at various opacity levels (100%, 90%, 80%, 70%, 60%, 50%, 40%, 30%)
- **Cards:** zinc-900/50 with white/10 borders
- **Hover:** Primary color accents on borders and text

### Patterns
- `rounded-none` on all buttons (sharp corners)
- `tracking-widest uppercase` on all labels and button text
- `border border-white/10` on cards and images
- `grayscale` to `hover:grayscale-0` transitions on images
- `bg-primary/10 border-primary/30` for accent badges
- Framer Motion `fadeInUp` and `staggerContainer` animations on all sections

## UI Component Library
55 shadcn/ui components are installed. Actively used: Button, Input, Textarea, Select, Accordion, Tooltip, Toast.
