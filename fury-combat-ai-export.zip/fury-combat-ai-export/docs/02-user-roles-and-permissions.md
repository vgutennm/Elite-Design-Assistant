# 02 - User Roles and Permissions

## Overview

This is a public marketing website with no authentication, no user accounts, and no login system. There are no user roles or permissions in the application itself.

## Roles (Conceptual)

### Site Visitor (Public)
- Can view all pages (home page and 8 service detail pages)
- Can use phone and email CTAs to contact David Furie
- Can navigate using desktop or mobile navigation
- Can view the gallery and lightbox
- Can access Google Maps directions
- Can leave a Google review via the CTA link
- Cannot submit forms (the contact form is presentational only; it does not connect to a backend)

### Site Owner (David Furie)
- Manages content updates through the Replit development environment
- Does not have an admin panel or CMS
- Content changes require code edits to `Home.tsx`, `services.ts`, or `ServiceDetail.tsx`
- Deployment is handled through Replit's publish system

## Hidden Logic / Restrictions

- There is no gating, paywalling, or access restriction
- All content is publicly accessible
- The contact form on the home page is presentational; it does not submit data anywhere (there is no backend form handler)
- Phone and email CTAs use native `tel:` and `mailto:` links

## AI Analysis Note

This app has no auth system, which is intentional for a marketing site. If this pattern were extended to include booking, payments, or a client portal, authentication would need to be added. The current architecture cleanly separates the marketing frontend from any future authenticated features.
