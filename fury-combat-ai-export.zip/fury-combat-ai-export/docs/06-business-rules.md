# 06 - Business Rules

## Core Brand Rules

1. **Premium positioning only.** All copy must feel elite, calm, authoritative, premium, discreet, practical, real-world, founder-led, and tactical without being cartoonish.

2. **No fake content.** No fake statistics, no fake testimonials, no fabricated client counts, no invented awards. Only verifiable credentials.

3. **No emoji.** The site must never use emoji in any context.

4. **No generic language.** Avoid cheesy dojo language, generic fitness-gym language, low-end "free class" wording, cheesy comic-book copy, or cluttered template filler.

5. **Founder-led identity.** The brand is inseparable from David Furie. All messaging reinforces that training is directly with the founder, not with staff or assistants.

## Service Card Button Order

Every service card on the home page must display buttons in this exact order:
1. **Learn More** (links to service detail page) - primary filled red button
2. **Inquire by Phone** (tel: link) - outline button
3. **Inquire by Email** (mailto: link) - ghost button

Exception: Private Workshops uses "Request a Private Workshop" and "Contact David" labels.

## Service Detail Page Structure

Every service page must include these sections in order: Hero with price, Overview, Who This Is For, What You Get, Training Focus, Likely Outcomes, Why Choose This, FAQ, Related Services, CTA Section, Contact Strip.

## Pricing Display Rules

- Individual sessions show exact price: "$250 / session"
- Workshops show starting price: "Starting at $1,500"
- Price is displayed in a red-bordered badge in the hero section

## Contact Information

All contact references must use:
- Phone: (917) 340-2911 / tel:9173402911
- Email: david.furie@gmail.com
- Address: 24 Cobek Ct, Brooklyn, NY 11223
- Directions: Google Maps search URL

## SEO Rules

- One H1 per page
- Unique meta title and description per service page
- LocalBusiness/SportsActivityLocation schema on home page
- FAQ schema injected dynamically on service pages
- Social sameAs links in structured data

## Navigation Rules

- Desktop: Services dropdown shows all 8 services with prices
- Mobile: Expandable Services submenu within hamburger menu
- Service detail pages include "All Services" breadcrumb back link
- Footer includes dedicated Services column

## Image Rules

- 39 approved photos (001-039), mix of JPG and PNG
- Images loaded via Vite glob import with timestamp-tolerant filename matching
- Gallery uses grayscale-to-color hover transitions
- Hero images use low opacity (30-40%) as background overlays
