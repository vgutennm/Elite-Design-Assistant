# 09 - Notifications and Messaging

## Overview

This application has no notification system, no messaging center, and no push notifications. It is a static marketing website.

## What Exists

- **Toast component:** A shadcn/ui Toast component is installed and mounted (`Toaster` in `App.tsx`), but it is not actively triggered by any user action
- **No email sending:** The contact form is presentational; no emails are sent from the application
- **No SMS:** No text message functionality
- **No in-app messaging:** No chat, no message inbox, no notification bell

## Conversion Actions (External)

The site relies entirely on external communication channels:
- **Phone calls:** `tel:9173402911` links trigger the device's native phone dialer
- **Email:** `mailto:david.furie@gmail.com` links open the user's email client
- **Google Reviews:** Direct link to Google's review submission page

## AI Analysis Note

For future apps that need notifications, the Toast component is already installed and wired. The pattern of using native `tel:` and `mailto:` links for a service-based business is effective and worth preserving as a reusable pattern for businesses that prefer direct contact over form submissions.
