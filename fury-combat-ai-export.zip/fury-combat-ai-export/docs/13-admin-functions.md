# 13 - Admin Functions

## Overview

This application has no admin panel, no admin dashboard, and no administrative functions. All content management happens through direct code editing in the Replit development environment.

## Content Management (Code-Based)

### Updating Service Information
- Edit `src/data/services.ts` to change service titles, prices, descriptions, FAQs, or any service detail
- Changes require a code commit and redeployment

### Updating Home Page Content
- Edit `src/pages/Home.tsx` for hero text, intro text, FAQ content, section ordering
- Edit `src/data/services.ts` for service card content

### Updating Navigation
- Edit `src/components/SiteHeader.tsx` for nav links
- Edit `src/components/SiteFooter.tsx` for footer links

### Updating Photos
- Add new photos to the `attached_assets` folder with the `furycombat-website-photos-XXX` naming convention
- Reference them in the appropriate component files

### Updating Structured Data / SEO
- Edit `index.html` for home page schema
- Service page FAQ schema is auto-generated from `services.ts` data

## AI Analysis Note

For future apps that need admin functionality, the recommended approach would be:
- Build an admin dashboard using the existing shadcn/ui components
- Connect to the PostgreSQL database (already configured in the monorepo)
- Add authentication using Replit Auth (skill available)
- Create CRUD interfaces for services, content, and settings
- Consider a headless CMS integration for non-technical content management
