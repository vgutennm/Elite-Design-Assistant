# 18 - File Manifest

## Package Structure

```
fury-combat-ai-export/
├── app-source/
│   ├── fury-combat-src/           # Full frontend source code
│   │   ├── App.tsx                # Root component with router
│   │   ├── main.tsx               # React entry point
│   │   ├── index.css              # Complete design system / theme
│   │   ├── pages/
│   │   │   ├── Home.tsx           # Full single-page home (hero, services, gallery, contact, FAQ)
│   │   │   ├── ServiceDetail.tsx  # Shared service detail page template
│   │   │   └── not-found.tsx      # 404 page
│   │   ├── components/
│   │   │   ├── SiteHeader.tsx     # Sticky nav with dropdown + mobile menu
│   │   │   ├── SiteFooter.tsx     # 4-column footer
│   │   │   └── ui/               # 55 shadcn/ui components
│   │   ├── data/
│   │   │   └── services.ts       # Centralized service data (8 services)
│   │   ├── hooks/
│   │   │   ├── use-mobile.tsx     # Mobile breakpoint hook
│   │   │   └── use-toast.ts      # Toast notification hook
│   │   └── lib/
│   │       └── utils.ts          # Utility functions (cn)
│   ├── api-server-src/            # API server source (minimal)
│   │   ├── app.ts                # Express app setup
│   │   ├── index.ts              # Server entry point
│   │   ├── lib/logger.ts         # Pino logger setup
│   │   └── routes/               # API routes (health check only)
│   ├── lib/                       # Shared monorepo libraries
│   │   ├── api-client-react/     # Generated API client
│   │   ├── api-spec/             # OpenAPI spec + Orval config
│   │   ├── api-zod/              # Generated Zod schemas
│   │   └── db/                   # Drizzle ORM database setup
│   ├── index.html                # HTML entry with SEO structured data
│   ├── vite.config.ts            # Vite build configuration
│   ├── artifact.toml             # Replit artifact deployment config
│   ├── fury-combat-package.json  # Frontend package.json
│   ├── api-server-package.json   # API server package.json
│   ├── root-package.json         # Monorepo root package.json
│   ├── pnpm-workspace.yaml       # pnpm workspace config
│   ├── tsconfig.base.json        # Shared TypeScript config
│   └── replit.md                 # Project documentation
│
├── docs/                          # 18 analysis documents
│   ├── 01-app-overview.md
│   ├── 02-user-roles-and-permissions.md
│   ├── 03-main-workflows.md
│   ├── 04-ui-pages-and-components.md
│   ├── 05-database-schema-and-data-model.md
│   ├── 06-business-rules.md
│   ├── 07-validation-and-error-handling.md
│   ├── 08-auth-and-security.md
│   ├── 09-notifications-and-messaging.md
│   ├── 10-reporting-and-exports.md
│   ├── 11-integrations.md
│   ├── 12-help-guide-and-training.md
│   ├── 13-admin-functions.md
│   ├── 14-deployment-and-environments.md
│   ├── 15-known-issues-and-tech-debt.md
│   ├── 16-reusable-patterns-and-modules.md
│   ├── 17-ai-playbook-extraction-notes.md  ← START HERE
│   └── 18-file-manifest.md                 ← THIS FILE
│
├── config/
│   ├── environment-variables-template.md
│   ├── deployment-notes.md
│   └── run-instructions.md
│
└── database/
    └── schema-notes.md
```

## What Is Included

- Full frontend source code (React + TypeScript + Tailwind CSS + shadcn/ui)
- API server source code (Express + TypeScript)
- Shared monorepo libraries (API client, OpenAPI spec, Zod schemas, database config)
- Build and deployment configuration files
- 18 comprehensive analysis documents written for AI consumption
- Configuration templates and instructions

## What Is NOT Included

1. **Photo assets** - 39 images (001-039) totaling ~30MB are NOT included in the ZIP to keep the package size manageable. The images are JPG (001-022) and PNG (023-039) files named `furycombat-website-photos-XXX`.
2. **node_modules** - Dependencies are not included; install via `pnpm install`.
3. **Environment secrets** - No secret values are included. See `config/environment-variables-template.md` for variable names and descriptions.
4. **Build output** - The `dist/` folder is not included; rebuild with `pnpm --filter @workspace/fury-combat run build`.
5. **Attached text files** - Original user specification documents are not included.
6. **Mockup sandbox** - The design prototyping artifact is not included as it is a development tool, not part of the production app.
