# 05 - Database Schema and Data Model

## Overview

This application does not use a database for the marketing website. All content is hardcoded in TypeScript source files.

## Data Model (In-Code)

### Service Data (`src/data/services.ts`)

The primary data structure is the `ServiceData` interface:

```
ServiceData {
  title: string           // Display name (e.g., "Private Instruction")
  route: string           // URL slug (e.g., "/private-instruction")
  price: string           // Display price (e.g., "$250 / session")
  metaTitle: string       // HTML title tag content
  metaDescription: string // HTML meta description content
  subheadline: string     // Short supporting text below H1
  overview: string        // Paragraph explaining the service
  whoFor: string[]        // List of ideal client descriptions
  whatYouGet: string[]    // List of session inclusions
  trainingFocus: string[] // List of training areas
  likelyOutcomes: string[]// List of expected benefits
  whyChoose: string       // Single paragraph differentiator
  faqs: { q: string; a: string }[] // 5 Q&A pairs
  relatedSlugs: string[]  // Routes of 2-3 related services
  heroImage?: string      // Filename of hero background image
}
```

There are 8 service records in the `allServices` array.

### Service Routes Map (`serviceRoutes`)
A `Record<string, string>` mapping service titles to their URL routes, used by the home page service cards to generate Learn More links.

### Home Page Data (in `Home.tsx`)
- `services` array: 8 objects with `title`, `price`, `desc`, `isWorkshop` (used for button label variants)
- `faqs` array: 8 objects with `q` and `a` strings
- Gallery image file list: 19 filenames
- Navigation links: defined in SiteHeader

### Asset Loading
Images are loaded via Vite's `import.meta.glob` with a custom `asset()` function that matches filenames by prefix (ignoring timestamps in filenames). 39 photos total (001-039).

## Monorepo Database Infrastructure (Not Used by Fury Combat)

The monorepo includes a database package (`lib/db`) with:
- Drizzle ORM setup for PostgreSQL
- Empty schema (no tables defined)
- `DATABASE_URL` environment variable connection
- Migration support via `drizzle-kit`

This infrastructure exists for the API server but is not connected to the marketing website.

## AI Analysis Note

The key pattern here is a content-heavy marketing site where all data lives in TypeScript files rather than a CMS or database. The `ServiceData` interface is a strong, reusable template for any service-based business. If this app were extended, the service data could be moved to a CMS or database with the same interface shape.
