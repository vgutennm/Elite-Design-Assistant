# 01 - App Overview

## What the App Does

Fury Combat Systems is a premium marketing website for an elite, founder-led private martial arts and tactical training brand based in Brooklyn, New York. The site serves as the primary digital presence for Grandmaster Dr. David Furie's private instruction business.

The website includes:
- A single-page home experience with hero, authority credentials, service offerings, gallery, contact, and FAQ sections
- 8 dedicated service detail pages, each with full marketing copy, pricing, FAQs, and calls to action
- Client-side routing via wouter for smooth navigation between pages
- A Services dropdown in the sticky navigation
- SEO-optimized structured data (LocalBusiness, FAQ schema)
- Responsive mobile-first design with a dark premium aesthetic

## Who It Is For

- **Primary audience:** Higher-income adults, executives, professionals, families, and serious individuals in the Brooklyn/NYC area seeking private, one-on-one martial arts and tactical training
- **Secondary audience:** Women seeking safety training, young adults preparing for independence, organizations seeking private workshops
- **Business owner:** Grandmaster Dr. David Furie, the sole instructor and founder

## What Business Problem It Solves

David Furie needed a premium digital presence that positions his private instruction brand above generic martial arts gym websites. The site must:
- Communicate elite-level credentials without fake testimonials or cheesy gym language
- Present 8 distinct service offerings with clear pricing and value propositions
- Drive phone calls and email inquiries as the primary conversion actions
- Support local SEO for Brooklyn-area private training searches

## Core Value

The core value is positioning Fury Combat as a premium, discreet, founder-led private training brand, not a commodity fitness service. Every design and copy decision reinforces this: dark elegant aesthetics, Cinzel serif typography, authoritative but not aggressive copy, and direct founder access via phone/email CTAs.

## Version / Stage

This is version 1.0 of the production website. It is fully deployed and publicly accessible. The site is a static React SPA with no database, no user accounts, and no e-commerce. It is a marketing/lead-generation site.

## What Success Looks Like

- Prospects find the site via Google search for private martial arts training in Brooklyn
- Visitors immediately understand the premium positioning and David's credentials
- Service pages clearly explain what each offering includes, who it is for, and likely outcomes
- Visitors convert by calling (917) 340-2911 or emailing david.furie@gmail.com
- The site leaves a Google review trail via the review CTA
